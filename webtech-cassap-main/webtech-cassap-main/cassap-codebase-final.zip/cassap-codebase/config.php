<?php
    define("servername", "localhost:3307");
    define("username", "root");
    define("password", "");
    define("database", "lab_post");

    $connection = mysqli_connect(servername, username, password, database);
?>